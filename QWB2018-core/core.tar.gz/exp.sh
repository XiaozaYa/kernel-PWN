#!/bin/sh

gcc exp.c -static -masm=intel -o fs/exp

cd fs
find . | cpio -o --format=newc > ../core.cpio

cd ..
gzip core.cpio
./start.sh
