#!/bin/sh

gcc exp.c -static -masm=intel -pthread -Os -w -o fs/exp

cd fs
find . | cpio -o --format=newc > ../rootfs.cpio

cd ..
gzip rootfs.cpio
mv rootfs.cpio.gz rootfs.cpio
