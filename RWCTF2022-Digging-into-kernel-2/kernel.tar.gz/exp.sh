#!/bin/sh

gcc modprobe_exp.c -static -masm=intel -pthread -Os -w -o fs/modprobe_exp
#gcc n_tty_osp_exp.c -static -masm=intel -pthread -Os -w -o fs/n_tty_opsexp

cd fs
find . | cpio -o --format=newc > ../rootfs.cpio

cd ..
