#!/bin/sh

gcc exp_cred.c -static -w -o fs/exp_cred
gcc exp_tty.c -static -w -o fs/exp_tty
gcc exp_seq.c -static -w -o fs/exp_seq
gcc exp_noread_ldt.c -static -w -o fs/exp_noread_ldt
gcc exp_noread_msg.c -static -w -o fs/exp_noread_msg

cd fs
find . | cpio -o --format=newc > ../rootfs.cpio

cd ..
./boot.sh
