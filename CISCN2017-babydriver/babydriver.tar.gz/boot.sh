#!/bin/bash

qemu-system-x86_64 \
-initrd rootfs.cpio \
-kernel bzImage \
-cpu kvm64,+smep \
-append 'console=ttyS0 root=/dev/ram kpti=1 nokaslr oops=panic panic=1' \
-monitor /dev/null \
-enable-kvm \
-m 256M \
--nographic  \
-smp cores=1,threads=1 \
-s
