#!/bin/sh

sudo mount rootfs.img fs
sudo gcc -static -masm=intel -w exp.c -o fs/exp
sudo umount fs
