#!/bin/sh

gcc exp.c -static -masm=intel -pthread -Os -w -o fs/exp
gcc exp_seq.c -static -masm=intel -pthread -Os -w -o fs/exp_seq

cd fs
find . | cpio -o --format=newc > ../rootfs.cpio

cd ..

