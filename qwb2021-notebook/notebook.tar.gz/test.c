#include <sys/types.h>
#include <stdio.h>
#include <linux/userfaultfd.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <poll.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <poll.h>
#include <sys/sem.h>
#include <semaphore.h>

void *addr;
char src[0x1000];
pthread_t uffd_pt;


void* uffd_handler(void* args)
{
	puts("uffd handler");
	struct uffd_msg msg;
	struct uffdio_copy uffdio_copy;	

	for(;;)
	{
		struct pollfd pollfd;
		pollfd.fd = (long)args;
		pollfd.events = POLLIN;
		int res = poll(&pollfd, 1, -1);
		if (res == -1) puts("poll ERROR"), exit(-1);

		int n = read((int)args, &msg, sizeof(msg));
		if (n == 0) puts("EOF on userfaultfd"), exit(-1);
		if (n == -1) puts("ERROR on userfaultfd"), exit(-1);

		puts("poll extract");
		for (int i = 0; i < 10; i++) printf("%d ", i);
		puts("");
		sleep(100);
	
		if (msg.event != UFFD_EVENT_PAGEFAULT) puts("Unexcepted event on userfaultfd"), exit(-1);
		uffdio_copy.src = src;
		uffdio_copy.dst = addr;
		uffdio_copy.len = 0x1000;
		uffdio_copy.mode = 0;
		uffdio_copy.copy = 0;
		if (ioctl((int)args, UFFDIO_COPY, &uffdio_copy) == -1) puts("ioctl--UFFDIO_COPY ERROR"), exit(-1);
		return NULL;
	}
}

void register_userfaultfd(void* fault_page)
{
	int uffd;
	struct uffdio_api uffdio_api;
	struct uffdio_register uffdio_register;
	
	uffd = syscall(__NR_userfaultfd, O_NONBLOCK|O_CLOEXEC);
	if (uffd == -1) puts("syscall--userfaultfd ERROR"), exit(-1);	

	uffdio_api.api = UFFD_API;
	uffdio_api.features = 0;
	if (ioctl(uffd, UFFDIO_API, &uffdio_api) == -1) puts("ioctl--UFFDIO_API ERROR"), exit(-1);

	uffdio_register.range.start = (unsigned long long)fault_page;
	uffdio_register.range.len = 0x1000;
	uffdio_register.mode = UFFDIO_REGISTER_MODE_MISSING;
	if (ioctl(uffd, UFFDIO_REGISTER, &uffdio_register) == -1) puts("ioctl--UFFDIO_REGISTER ERROR"), exit(-1);
	
	int res = pthread_create(&uffd_pt, NULL, uffd_handler, (void*)uffd);
	if (res == -1) puts("pthread_create ERROR"), exit(-1);
}

sem_t sem0, sem1;
void func0(void* args)
{
	sem_wait(&sem0);
	puts("thread 0 start");
	void *ptr = (void*)*(unsigned long long*)args;
	printf("thread 0 end\n ptr: %p\n", ptr);
}

void func1(void* args)
{
	sem_wait(&sem1);
	puts("thread 1 start");
	void *ptr = (void*)*(unsigned long long*)args;
	printf("heread 1 end \n ptr: %p\n", ptr);
}

int main(int argc, char** argv, char** envp)
{
	sem_init(&sem0, 0, 0);
	sem_init(&sem1, 0, 0);
	addr = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE, MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);
	register_userfaultfd(addr);
	for (int i = 0; i < 0x30; i++) src[i] = 'A';
	pthread_t pt_r0, pt_r1;
	pthread_create(&pt_r0, NULL, func0, (void*)addr);
	pthread_create(&pt_r1, NULL, func1, (void*)addr);
	sem_post(&sem0);
	sleep(1);
	sem_post(&sem1);
	sleep(1);	
	puts("main main");

	pthread_join(pt_r0, NULL);
	pthread_join(pt_r1, NULL);
	return 0;
}
