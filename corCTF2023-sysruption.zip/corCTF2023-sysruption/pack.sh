#!/bin/sh

gcc -static -w exploit.c -o fs/home/ctf/exploit
cd fs
find . | cpio -o --format=newc > ../initramfs.cpio
cd ..
gzip initramfs.cpio
./run.sh
