#!/bin/sh

gcc -masm=intel -static -w exp.c -o fs/exp

cd fs
find . | cpio -o --format=newc > ../rootfs.cpio

cd ..
