#!/bin/sh

gcc exp.c -static -masm=intel -pthread -g -o fs/exp
gcc panic_exp.c -static -masm=intel -g -o fs/panic_exp

cd fs
find . | cpio -o --format=newc > ../core.cpio

cd ..
./start.sh
