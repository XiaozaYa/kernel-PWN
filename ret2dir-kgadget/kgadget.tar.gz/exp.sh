#!/bin/sh

gcc exp.c -static -masm=intel -g -o fs/exp

cd fs
find . | cpio -o --format=newc > ../rootfs.cpio

cd ..
./run.sh
