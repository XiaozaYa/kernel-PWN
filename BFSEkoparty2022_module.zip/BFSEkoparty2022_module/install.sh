#!/bin/sh
sudo insmod blunder.ko
sudo chmod 666 /dev/blunder
