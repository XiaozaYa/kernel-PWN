gcc -static exploit.c -masm=intel -w -o exploit
