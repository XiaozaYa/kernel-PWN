#!/bin/sh

#gcc ldt_exp.c -static -w -masm=intel -pthread -g -o fs/ldt_exp
#gcc user_key_payload_exp.c -static -w -masm=intel -pthread -g -o fs/user_key_payload_exp
#gcc msg_msg_exp.c -static -w -masm=intel -pthread -g -o fs/msg_msg_exp
gcc pipe_buffer_exp.c -static -w -masm=intel -pthread -g -o fs/pipe_buffer_exp


cd fs
find . | cpio -o --format=newc > ../rootfs.img

cd ..
