#!/bin/sh

qemu-system-x86_64  \
-m 128M \
-cpu kvm64,+smep \
-kernel ./bzImage \
-initrd rootfs.img.gz \
-nographic \
-s \
-append "console=ttyS0 kaslr quiet noapic"
