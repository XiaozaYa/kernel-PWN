#!/bin/sh

gcc exp.c -static -masm=intel -pthread -Os -w -o fs/exp

cd fs
./gen.sh

cd ..
./start.sh
